﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raffler.Models
{
    public class NameBasketModel
    {
        public string Name { get; set; }
        public List<int> Baskets { get; set; }
    }
}
